# MunroLibrary
Java Library for Munro Dataset

Build on Java 11.0.7 Amazon Corretto.

To run, first make sure you have at least JDK 11.0.7 installed, then simply open the project in your IDE, change the filePath variable in MunroMain for the CSV file (munro_data_changed) to the correct file path.